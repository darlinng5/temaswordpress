<?php 
   if(class_exists('Gavias_Addon_Form_Ajax')){
      echo Gavias_Addon_Form_Ajax::instance()->html_form();
   } 
?>
